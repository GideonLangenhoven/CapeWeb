import React, { useEffect, useState, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../styles/Header.css';
import SplitRevealLogo from './SplitRevealLogo';

const navItems = [
  { label: 'Services', to: '/services' },
  { label: 'Gallery', to: '/gallery' },
  { label: 'Learn', to: '/learn' },
  { label: 'Resources', to: '/resources' },
  { label: 'Contact', to: '/contact' }
];

function Header() {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isKeyholeActive, setIsKeyholeActive] = useState(false);
  const selectorRef = useRef(null);
  const navRef = useRef(null);

  useEffect(() => {
    const updateScrollState = () => {
      // Scroll detection disabled to keep header consistent (Solid Black)
      // setIsScrolled(false);
      // setIsKeyholeActive(false);
    };

    updateScrollState();
    // Delay a second measurement to ensure DOM layout is ready
    const timer = setTimeout(updateScrollState, 50);

    window.addEventListener('resize', updateScrollState);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', updateScrollState);
    };
  }, [location.pathname]);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isMenuOpen]);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  // Update selector position
  useEffect(() => {
    const updateSelector = () => {
      if (!selectorRef.current || !navRef.current) return;

      const activeItem = navRef.current.querySelector('.nav-item.is-active');
      if (activeItem) {
        const left = activeItem.offsetLeft;
        const width = activeItem.offsetWidth;

        selectorRef.current.style.left = `${left}px`;
        selectorRef.current.style.width = `${width}px`;
        selectorRef.current.style.height = '';
        selectorRef.current.style.opacity = '1';
      } else {
        selectorRef.current.style.opacity = '0';
        selectorRef.current.style.width = '0px';
        selectorRef.current.style.left = '0px';
        selectorRef.current.style.height = '';
      }
    };

    updateSelector();
    window.addEventListener('resize', updateSelector);

    // Delay to ensure DOM is ready
    const timer = setTimeout(updateSelector, 100);
    const timer2 = setTimeout(updateSelector, 300);

    return () => {
      window.removeEventListener('resize', updateSelector);
      clearTimeout(timer);
      clearTimeout(timer2);
    };
  }, [location.pathname]);

  const isActive = (path) => location.pathname === path;



  return (
    <header className={`site-header ${isScrolled ? 'site-header--scrolled' : ''} ${isKeyholeActive ? 'site-header--keyhole-active' : ''}`}>
      <nav className="navbar navbar-expand-custom navbar-mainbg">
        <div className="container header-container">
          <a href="/" className="navbar-brand navbar-logo" aria-label="capeweb home">
            <SplitRevealLogo />
          </a>

          <button
            className={`navbar-toggler ${isMenuOpen ? 'navbar-toggler--open' : ''}`}
            type="button"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            aria-expanded={isMenuOpen}
            aria-controls="navbarSupportedContent"
            aria-label="Toggle navigation menu"
          >
            <span />
            <span />
            <span />
          </button>

          <div
            className={`navbar-collapse ${isMenuOpen ? 'show' : ''}`}
            id="navbarSupportedContent"
            ref={navRef}
          >
            <ul className="navbar-nav ml-auto">
              <div className="hori-selector" ref={selectorRef}>
                <div className="left"></div>
                <div className="right"></div>
              </div>
              {navItems.map((item) => (
                <li key={item.to} className={`nav-item ${isActive(item.to) ? 'is-active' : ''}`}>
                  <Link to={item.to} className="nav-link">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="header-actions">
            <a href="https://calendly.com/capeweb/discovery-call" className="btn btn-primary btn-nav" aria-label="Book a Free Strategy Call" target="_blank" rel="noopener noreferrer">
              Book a Free Strategy Call
            </a>
          </div>
        </div>
      </nav>

      <div className={`mobile-nav ${isMenuOpen ? 'mobile-nav--open' : ''}`} id="mobile-nav">
        <div className="mobile-nav__inner">
          <ul>
            {navItems.filter((item) => !item.isSecondary).map((item) => (
              <li key={item.to} className={isActive(item.to) ? 'is-active' : ''}>
                <Link to={item.to}>{item.label}</Link>
              </li>
            ))}
          </ul>
          {navItems.some((item) => item.isSecondary) && (
            <details className="mobile-nav__more">
              <summary>More</summary>
              <ul>
                {navItems.filter((item) => item.isSecondary).map((item) => (
                  <li key={item.to} className={isActive(item.to) ? 'is-active' : ''}>
                    <Link to={item.to}>{item.label}</Link>
                  </li>
                ))}
              </ul>
            </details>
          )}
          <div className="mobile-nav__cta">
            <a href="https://calendly.com/capeweb/discovery-call" className="btn btn-primary" target="_blank" rel="noopener noreferrer">
              Book a Free Strategy Call
            </a>
            <Link to="/resources" className="btn btn-ghost">
              Download the AI Time-Saver Guide
            </Link>
          </div>
        </div>
      </div>
      {isMenuOpen && <div className="mobile-nav__overlay" onClick={() => setIsMenuOpen(false)} aria-hidden="true" />}
    </header>
  );
}

export default Header;
